readme

%%%%%%%%%%%%%%%%%%%%%%%%%


Figure 1 -- This is currently a snippet of a docket sheet as an image; I've attached a docket sheet in .csv format to use instead.  


Figure 2 -- This is a "Smart Art" thing generated in Word.  I'm open to any and all suggestions for improvement.


Figure 3 -- This was generated using commands in Excel working on an underlying spreadsheet (and I know that Dan said it's busy); I may have to talk with the designers about what to do.  I'm also open to cutting it.


Figure 4 -- I generated this just using Excel -- I've attached a simple spreadsheet with the totals.


Figure  5 -- These are screenshots from Tableau.  I'm open to any and all suggestions for improvement.


Figure 6 -- See attached.


Figure 7 -- See attached.


Figure 8 -- These were from a presentation by the student team of their results.  They can be easily reconstructed in Excel, but I'm open to advice from the graphic designers.