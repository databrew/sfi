

The network graphic is derived from a web-based interface that uses cytoscape.js. The backend data comes from Python using networkx.

